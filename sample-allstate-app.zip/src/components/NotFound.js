export default function() {
    return <h1>Not Found</h1>
}