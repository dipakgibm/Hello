import { useOutletContext, useParams } from "react-router-dom"

export default function() {

    const params = useParams();
    const context = useOutletContext();

    return (
        <>
            <h1>Details { context.temp } </h1>
            <button onClick={() => context.setTemp("From the Outlet")} >Click the child outlet</button> 
            <h3>{ params.fname }</h3>
        </>
    )
}