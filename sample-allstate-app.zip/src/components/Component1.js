import React, { useEffect, useState } from 'react';
import Component2 from './Component2';

function Component1(props) {

  console.log(props.children)

  const [flag, setFlag] = useState(false);
  const [todos, setTodos] = useState([]);
  
  useEffect(() => {
    console.log('Flag has changed')
  }, [flag]);

  useEffect(() => {
    console.log('CDU');
  });
  
  useEffect(() => {
    console.log('CDM');
    const URL = 'https://jsonplaceholder.typicode.com/todos';
    fetch(URL).then(response => response.json()).then(json => setTodos(json)).catch((err) => console.log(err))
  }, []);

  useEffect(() => {
    return () => {
      console.log('CWU');
    }
  });


  return (
    <>
      <>
        <h1>Component1 is here</h1>
        <button onClick={() => props.setFullName("Sam")}>Click</button>
        <Component2 fName={props.fName} />
        {/* <Component1Class fName={props.fName} setFullName={props.setFullName}  /> */}
        { props.children }
        {/* <ul>
          { todos.map(todo => <li>{ todo.title }</li>) }
        </ul> */}

      </>
      <h1></h1>
      <></>
    </>
  );
}

export default Component1;


class Component1Class extends React.Component {
  constructor(props) {
    super(props);
  }

  state = {
    fullName: 'John',
    todos: []
  }

  foo = () => {
    console.log('foo');
    this.setState({
      fullName: 'Sam'
    })
  }

  componentDidMount() {
    console.log('CDM');

    console.log('CDM');
    const URL = 'https://jsonplaceholder.typicode.com/todos';
    fetch(URL).then(response => response.json()).then(json => this.setState({ todos: json })).catch((err) => console.log(err))
  }

  componentDidUpdate() {
    console.log('CDU');
    if(false) { // need to set a stopping condition to avoid infinite loop
      this.setState()
    }
  }

  componentWillUnmount() {
    console.log('CWU')
  }
  
  render() {
    return (
      <>
      <>
        <h1>Component1 is here</h1>
        <button onClick={() => this.props.setFullName("Sam")}>Click</button>
        <button onClick={() => this.foo()}>Click Foo</button>
        { this.state.fullName }
        <ul>
          { this.state.todos.map(todo => <li>{ todo.title }</li>) }
        </ul>
        <Component2 fName={this.props.fName} />
      </>
      <h1></h1>
      <></>
    </>
    );
  }
}

// 1. Mounting - constructor, R, CDM
// 2. Update - R, CDU
// 3. Unmount - CWU