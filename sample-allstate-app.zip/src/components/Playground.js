import { useState } from 'react';
import Component1 from './Component1';
import Form from './Form';

export default function () {
  // let fullName = "John";
  const lastName = 'Doe';

  const [fullName, setFullName] = useState('John');

  // const setFullName = (name) => {
  //   fullName = name;
  //   console.log(fullName)
  // }

  return (
    <>
      <div>Hello World</div>
      <Component1 fName={fullName} lName={lastName} setFullName={setFullName}>
          <h2>Hello</h2>
          <h2>Hi</h2>
      </Component1>
      <h1>Forms</h1>
      <Form />
    </>
  );
}
