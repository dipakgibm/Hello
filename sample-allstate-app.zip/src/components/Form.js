import React, { useState } from "react";
import { Outlet, useNavigate } from "react-router-dom";

function Form() {

    const navigate = useNavigate();

    const [temp, setTemp] = useState("temp data string");

    // const [name, setName] = useState("John");
    const [formData, setFormData] = useState({
        fname: '',
        age: '',
        address: ''
    });

    const [list, setList] = useState([])

    const handleChange = (event) => {
        // setName(event.target.value)
        setFormData({
            ...formData,
            [event.target.name]: event.target.value
        })
    }
    const handleSubmit = (event) => {
        event.preventDefault();
        console.log("Submitted", formData);

        setList([...list, formData]);

    }

    const showDetails = (name) => {
        // do some tasks here and THEN you want to route
        navigate("/form/" + name);
    }

    return (<>
        <form>
            <input name="fname" type="text" value={formData.name} onChange={handleChange} />
            <input name="age" type="text" value={formData.age} onChange={handleChange} />
            <input name="address" type="text" value={formData.address} onChange={handleChange} />
            <button type="submit" onClick={handleSubmit} >Submit</button>
        </form>
        
        <h1>List</h1>
        <ol>
            { list.map(person => <li> Name: { person.fname }, Age: { person.age }
                <button onClick={() => showDetails(person.fname)}>Details</button>
             </li>) }
        </ol>
        <Outlet context={ { temp, setTemp } } />
        </>)
}
export default Form;

class FormClass extends React.Component {
    state = {
        fname: 'John',
        age: '',
        address: ''
    }

    
    handleChange = (event) => {
        this.setState({
            [event.target.name]: event.target.value
        })
    }
    handleSubmit = (event) => {
        event.preventDefault();
        console.log("Submitted", this.state.name)
    }

    render() {
        return (
            <form>
                <input type="text" name="fname" value={this.state.fname} onChange={this.handleChange} />
                <input type="text" name="age"  value={this.state.age} onChange={this.handleChange} />
                <input type="text" name="address" value={this.state.address} onChange={this.handleChange} />
                <button type="submit" onClick={this.handleSubmit} >Submit</button>
            </form>
        )
    }
}