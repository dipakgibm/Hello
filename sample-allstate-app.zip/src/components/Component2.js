function Component2(props) {
    return(
      <h4>{ props.fName }</h4>
    )
}

export default Component2;