import React, { useState } from "react";
import { Link, Route, Routes } from "react-router-dom";
import Component1 from "./components/Component1";
import Form from "./components/Form";
import NotFound from "./components/NotFound";
import PersonDetails from "./components/PersonDetails";
import Playground from "./components/Playground";

function App() {

  const isLoggedIn = false;

  return (
    <>
      <Link to="/"> Home </Link> | 
      <Link to="/form"> Form </Link> | 
      <Link to="/playground"> Playground </Link>

      <Routes>
        <Route path="/form" element={isLoggedIn ? <Form /> : <NotFound />} >
            <Route path=":fname" element={<PersonDetails/>} />
        </Route>
        <Route path="/playground" element={<Playground />} />
        
      </Routes>
    </>
  );
}

export default App;