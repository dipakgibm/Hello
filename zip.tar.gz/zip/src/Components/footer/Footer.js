import React from "react";
import { Navbar } from "react-bootstrap";

export const Footer = () => {
  return (
    <Navbar
      bg="light"
      variant="light"
      fixed="bottom"
      className="justify-content-center"
    >
      <Navbar.Text>India Today @2022</Navbar.Text>
    </Navbar>
  );
};
