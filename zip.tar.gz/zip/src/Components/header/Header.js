import React from "react";
import { Navbar } from "react-bootstrap";
import { Categories } from "../dashboard/Categories";
export const Header = () => {
  return (
    <Navbar bg="primary" variant="light" fixed="top" className="justify-content-center">
      <Navbar.Brand href="#">Home</Navbar.Brand>
      <Navbar.Brand href="/Dashboard">Trending</Navbar.Brand>
      <Navbar.Brand href="/Categories">Categories</Navbar.Brand>
    </Navbar>
  );
};
