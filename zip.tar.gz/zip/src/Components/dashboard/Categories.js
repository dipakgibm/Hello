import React from "react";
import { CardDeck } from "react-bootstrap";
import { Card } from "../card/Card";
import { NewsService } from "./../../newsapi/services/newsServices";

export class Categories extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      articles: [],
    };
    this.newsService = new NewsService();
  }

  componentDidMount() {
    this.newsService.getCategoriesArticles().then((data) => {
      this.setState({
        articles: data.articles,
      });
      console.log(data.articles);
    });
  }

  render() {
    return (
      <div>
        <CardDeck>
          {this.state.articles.map((article, i) => (
            <Card key={i} {...article}></Card>
          ))}
        </CardDeck>
      </div>
    );
  }
}
