import React, { useState } from "react";

function Form() {

    // const [name, setName] = useState("John");
    const [formData, setFormData] = useState({
        fname: '',
        age: '',
        address: ''
    })

    const handleChange = (event) => {
        // setName(event.target.value)
        setFormData({
            ...formData,
            [event.target.name]: event.target.vaue
        })
    }
    const handleSubmit = (event) => {
        event.preventDefault();
        console.log("Submitted", formData)
    }

    return (
        <form>
            <input name="fname" type="text" value={formData.name} onChange={handleChange} />
            <button type="submit" onClick={handleSubmit} >Submit</button>
        </form>
    )
}
export default Form;

class FormClass extends React.Component {
    state = {
        fname: 'John',
        age: '',
        address: ''
    }

    
    handleChange = (event) => {
        this.setState({
            [event.target.name]: event.target.value
        })
    }
    handleSubmit = (event) => {
        event.preventDefault();
        console.log("Submitted", this.state.name)
    }

    render() {
        return (
            <form>
                <input type="text" name="fname" value={this.state.fname} onChange={this.handleChange} />
                <input type="text" name="age"  value={this.state.age} onChange={this.handleChange} />
                <input type="text" name="address" value={this.state.address} onChange={this.handleChange} />
                <button type="submit" onClick={this.handleSubmit} >Submit</button>
            </form>
        )
    }
}