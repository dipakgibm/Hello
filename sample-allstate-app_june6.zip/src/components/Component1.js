import React from 'react';
import Component2 from './Component2';

function Component1(props) {
  return (
    <>
      <>
        <h1>Component1 is here</h1>
        <button onClick={() => props.setFullName("Sam")}>Click</button>
        <Component2 fName={props.fName} />
        <Component1Class fName={props.fName} setFullName={props.setFullName}  />
      </>
      <h1></h1>
      <></>
    </>
  );
}

export default Component1;


class Component1Class extends React.Component {
  constructor(props) {
    super(props);
  }

  state = {
    fullName: 'John'
  }

  foo = () => {
    console.log('foo');
    this.setState({
      fullName: 'Sam'
    })
  }
  
  render() {
    return (
      <>
      <>
        <h1>Component1 is here</h1>
        <button onClick={() => this.props.setFullName("Sam")}>Click</button>
        <button onClick={() => this.foo()}>Click Foo</button>
        { this.state.fullName }
        <Component2 fName={this.props.fName} />
      </>
      <h1></h1>
      <></>
    </>
    );
  }
}